# Codecraft-19

## Run

```bash
$ cd CodeCraft-2019
$ g++ -o output.o CodeCraft-2019.cpp util.cpp sm.cpp -std=c++11
$ ./output.o ../config/car.txt ../config/road.txt ../config/cross.txt answer.txt
查看答案文件answer.txt
```

## Build

```bash
$ sh build.sh
提交CodeCraft-code.tar.gz
```
